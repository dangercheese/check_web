#!/usr/bin/python
# -*- coding: UTF8 -*- 
#
# Copyright (C) 2012 Edgewall Software
#
#  Authors:   
#    guolei@eefocus.com  < http://www.weibo.com/u/2001677023 > <qq:674653>
import httplib,sys,subprocess,smtplib,pickle
from email.mime.text import MIMEText
###############mail address##############
mailto_list=["guolei@eefocus.com","test@qq.com"]
###############send mail#################
mail_host="imap.eefocus.com"
mail_user="test"
mail_pass="test"
mail_postfix="imap.eefocus.com"
##############develop###################
def check_webserver(address):
    time = subprocess.Popen("date +'%Y-%m-%d %H:%M:%S'", shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    date = time.stdout.read().rstrip()
    try:
        conn = httplib.HTTPConnection(address, timeout=10)
        req = conn.request('GET', '/')
        response = conn.getresponse()
    except:
	judge_tf('%s'%address,'false')
	send_mail(mailto_list,'%s is not link'%address ,'HTTP is not link :\n %s\n %s\n' %(address,date))
	print '%s error'%address
	return False
    finally:
        conn.close()
    if response.status in [200, 301, 302]:
        with open('status_tmp', 'rb') as f:
            domain = pickle.load(f)
            if not domain[address] in "ture":
               send_mail(mailto_list,'%s is ok ' %address,'HTTP response status:\n %s status is %s\n %s\n' %(address, response.status, date))
               with open('status_tmp', 'wb') as fw:
                   domain[address] = "ture"
                   pickle.dump(domain,fw)
	       print 'response status: %s' % response.status
    else:
	judge_tf('%s'%address,'false')
	print '%s error'%address
	send_mail(mailto_list,'%s is not link'%address ,'HTTP response status:\n %s %s\n %s\n' %(address, response.status, date))
	pass
####################################################################################################
def send_mail(to_list,sub,content):
    time = subprocess.Popen("date +'%Y-%m-%d %H:%M:%S'", shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    date = time.stdout.read().rstrip()
    me=mail_user+"<"+mail_user+"@"+mail_postfix+">"
    msg = MIMEText('%s\n' %(content))
    msg['Subject'] = '%s' %sub
    msg['From'] = me
    msg['date']= '%s' %date
    msg['To'] = ";".join(to_list)
    try:
        s = smtplib.SMTP()
        s.connect(mail_host)
        s.login(mail_user,mail_pass)
        s.sendmail(me, to_list, msg.as_string())
        s.close()
        return True
    except Exception, e:
        print str(e)
        return False
####################################################################################################
def judge_tf(add,value1):
    print value1
    with open('status_tmp', 'rb') as f:
        domain = pickle.load(f)
        if not domain[add] in '%s'%value1:
            with open('status_tmp', 'wb') as fw:
                domain[add] = '%s' %value1
                pickle.dump(domain,fw)

if __name__ == '__main__':
    page_list = open('/etc/bin/check_web/web_check.txt', 'r')
    for line in page_list:
	line = line.rstrip()
    	check_webserver(line)
