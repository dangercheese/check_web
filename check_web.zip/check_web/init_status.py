#!/usr/bin/python
# -*- coding: UTF8 -*- 
#
# Copyright (C) 2012 Edgewall Software
#
#  Authors:   
#    guolei@eefocus.com  < http://www.weibo.com/u/2001677023 >
import pickle
domain = {}
domain[""] = "ture"
with open('status_tmp', 'wb') as f:
    pickle.dump(domain, f)
def init_status(line):
    with open('status_tmp', 'wb') as f:
       domain[line] = "ture"
       pickle.dump(domain, f)

page_list = open('web_check.txt', 'r')
for line in page_list:
   line = line.rstrip()
   init_status(line)
